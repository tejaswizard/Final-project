package Classes;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class StockTracker {

    private static final String API_KEY = "4W8USZD7K6PXDT4T"; 
    private static final String BASE_URL = "https://www.alphavantage.co/query";

    private final HttpClient client = HttpClient.newHttpClient();
    
    // Thread-safe set to hold multiple stock symbols
    private final Set<String> trackedStocks = ConcurrentHashMap.newKeySet();
    
    // Scheduler to run tasks periodically
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
    
    // Formatter using java.time
    private final DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    // --- Original Fetch Logic ---
    public String fetchStockQuote(String symbol) throws Exception {
        String url = BASE_URL
            + "?function=GLOBAL_QUOTE"
            + "&symbol=" + symbol
            + "&apikey=" + API_KEY;

        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(url))
            .GET()
            .build();

        HttpResponse<String> response = client.send(
            request, HttpResponse.BodyHandlers.ofString()
        );

        if (response.statusCode() != 200) {
            throw new RuntimeException("HTTP error: " + response.statusCode());
        }
        return response.body();
    }

    // --- Tracking Logic ---
    public void addStock(String symbol) {
        String upperSymbol = symbol.toUpperCase();
        trackedStocks.add(upperSymbol);
        System.out.println("✅ Added " + upperSymbol + " to tracking list.");
    }

    public void startTracking() {
        System.out.println("Starting stock tracker. Updates will occur every minute...");
        
        Runnable trackingTask = () -> {
            if (trackedStocks.isEmpty()) {
                return; // Skip if no stocks are added yet
            }

            // Using java.time to log the exact time of the API pull
            LocalDateTime now = LocalDateTime.now();
            System.out.println("Stock Update at " + now.format(timeFormatter) + ":");
            
            for (String symbol : trackedStocks) {
                try {
                    String result = fetchStockQuote(symbol);
 
                    System.out.println("Data for " + symbol + ": " + result);
                } catch (Exception e) {
                    System.err.println("❌ Failed to fetch quote for " + symbol + ": " + e.getMessage());
                }
            }
        };

        // Schedule the task to run initially with 0 delay, and then every 1 minute
        scheduler.scheduleAtFixedRate(trackingTask, 0, 1, TimeUnit.MINUTES);
    }

    // --- Main UI Loop ---
    public static void main(String[] args) {
        StockTracker tracker = new StockTracker();
        tracker.startTracking();

        Scanner scanner = new Scanner(System.in);
        System.out.println("\n[ Terminal Stock Tracker ]");
        System.out.println("Type a stock symbol to add it (e.g., AAPL). Type 'exit' to quit.");

        while (true) {
            String input = scanner.nextLine().trim();
            
            if (input.equalsIgnoreCase("exit")) {
                System.out.println("Shutting down tracker...");
                tracker.scheduler.shutdown(); // Gracefully stop the background thread
                break;
            } else if (!input.isEmpty()) {
                tracker.addStock(input);
            }
        }
        
        scanner.close();
    }
}