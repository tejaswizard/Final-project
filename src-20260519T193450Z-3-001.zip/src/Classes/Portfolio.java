package Classes;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Portfolio {

    private static final String PORTFOLIO_FILE = "portfolio.txt";
    private static final String SESSION_LOG_FILE = "session_log.txt";
    private static final String ALERTS_FILE = "alerts.txt";
    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final List<String> stocks = new ArrayList<>();
    private final Map<String, PriceAlert> priceAlerts = new HashMap<>();
    private final AlphaVantageClient avClient = new AlphaVantageClient();

    public Portfolio() {
        loadFromFile();
        loadAlertsFromFile();
    }

    public AlphaVantageClient getClient() {
        return avClient;
    }

    public void addStock(String symbol) {
        String upper = symbol.toUpperCase().trim();
        if (!stocks.contains(upper)) {
            stocks.add(upper);
            logActivity("Added " + upper + " to portfolio");
            System.out.println("✅ Added " + upper + " to portfolio.");
        } else {
            System.out.println(upper + " is already in your portfolio.");
        }
    }

    public void removeStock(String symbol) {
        String upper = symbol.toUpperCase().trim();
        if (stocks.remove(upper)) {
            logActivity("Removed " + upper + " from portfolio");
            System.out.println("✅ Removed " + upper + " from portfolio.");
        } else {
            System.out.println("❌ " + upper + " is not in your portfolio.");
        }
    }

    /**
     * Validation now goes through the client's cache — re-validating the same
     * symbol on the same day costs zero API calls.
     */
    public boolean validateStockSymbol(String symbol) {
        return avClient.validateStockSymbol(symbol);
    }

    public AlphaVantageClient.ValidationResult validateStockDetailed(String symbol) {
        return avClient.validateDetailed(symbol);
    }

    public List<String> getStocks() {
        return Collections.unmodifiableList(stocks);
    }

    /**
     * Builds the portfolio summary. Uses cache-first lookup, so opening the
     * portfolio repeatedly in one day costs at most one API call per stock.
     */
    public String getPortfolioSummary() {
        if (stocks.isEmpty()) {
            return "Your portfolio is empty.";
        }
        StringBuilder sb = new StringBuilder("Your Portfolio:\n");
        sb.append("═".repeat(70)).append("\n");

        for (String stock : stocks) {
            try {
                StockData data = avClient.getStockData(stock);
                String freshness = data.isFresh() ? "today" : "stale (" + data.getFetchDate() + ")";
                sb.append(String.format("%-8s | $%-10s | Change: %-8s (%s)%n",
                    data.getSymbol(), data.getPrice(), data.getChange(), data.getChangePercent()));
                sb.append(String.format("         | High: $%-10s Low: $%-10s | data: %s%n",
                    data.getHigh(), data.getLow(), freshness));
            } catch (AlphaVantageClient.InvalidStockException e) {
                sb.append(String.format("%-8s | ❌ invalid symbol%n", stock));
            } catch (AlphaVantageClient.RateLimitException e) {
                sb.append(String.format("%-8s | ⚠️  rate-limited (no fresh data)%n", stock));
            } catch (Exception e) {
                sb.append(String.format("%-8s | error: %s%n", stock, e.getMessage()));
            }
            sb.append("─".repeat(70)).append("\n");
        }
        sb.append("═".repeat(70)).append("\n");
        return sb.toString();
    }

    /**
     * Force-refreshes every stock by hitting the API again, even if cache is
     * fresh. Updates the cache file. Use sparingly — eats API quota.
     */
    public void refreshAllStocks() {
        if (stocks.isEmpty()) {
            System.out.println("Portfolio is empty — nothing to refresh.");
            return;
        }
        System.out.println("🔄 Refreshing all stocks from API...");
        int ok = 0, fail = 0;
        for (String stock : stocks) {
            try {
                StockData d = avClient.refreshStockData(stock);
                System.out.println("   ✅ " + d.getSymbol() + " — $" + d.getPrice());
                ok++;
            } catch (AlphaVantageClient.RateLimitException e) {
                System.out.println("   ⚠️  " + stock + ": rate-limited, stopping refresh.");
                fail++;
                break;
            } catch (Exception e) {
                System.out.println("   ❌ " + stock + ": " + e.getMessage());
                fail++;
            }
        }
        logActivity("Refreshed portfolio (" + ok + " ok, " + fail + " failed)");
        System.out.println("Done. " + ok + " refreshed, " + fail + " failed.");
    }

    public void showCacheStatus() {
        StockCache cache = avClient.getCache();
        if (cache.size() == 0) {
            System.out.println("Cache is empty.");
            return;
        }
        System.out.println("\nCached stocks (" + cache.size() + " entries):");
        System.out.println("─".repeat(70));
        for (StockData d : cache.all()) {
            String status = d.isValid() ? "VALID  " : "INVALID";
            String freshness = d.isFresh() ? "today" : "stale";
            System.out.printf("  %-8s %s  %s  fetched %s%n",
                d.getSymbol(), status, freshness, d.getFetchDate());
        }
        System.out.println("─".repeat(70) + "\n");
    }

    public void saveToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(PORTFOLIO_FILE))) {
            for (String stock : stocks) {
                writer.write(stock);
                writer.newLine();
            }
            logActivity("Portfolio saved (" + stocks.size() + " stock(s))");
            System.out.println("💾 Portfolio saved to " + PORTFOLIO_FILE);
        } catch (IOException e) {
            System.err.println("Failed to save portfolio: " + e.getMessage());
        }
    }

    private void loadFromFile() {
        File file = new File(PORTFOLIO_FILE);
        if (!file.exists()) {
            System.out.println("No saved portfolio found. Starting fresh.");
            return;
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String symbol = line.trim().toUpperCase();
                if (!symbol.isEmpty() && !stocks.contains(symbol)) {
                    stocks.add(symbol);
                }
            }
            System.out.println("📂 Loaded " + stocks.size() + " stock(s) from previous session.");
        } catch (IOException e) {
            System.err.println("Failed to load portfolio: " + e.getMessage());
        }
    }

    public void viewSessionHistory() {
        File file = new File(SESSION_LOG_FILE);
        if (!file.exists()) {
            System.out.println("No session history found.");
            return;
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            System.out.println("\n--- Session History ---");
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
            System.out.println("-----------------------\n");
        } catch (IOException e) {
            System.err.println("Failed to read session log: " + e.getMessage());
        }
    }

    public void setPriceAlert(String symbol, double lowerBound, double upperBound) {
        String upper = symbol.toUpperCase().trim();
        if (lowerBound >= upperBound) {
            System.out.println("❌ Invalid bounds: lower limit must be less than upper limit.");
            return;
        }
        priceAlerts.put(upper, new PriceAlert(upper, lowerBound, upperBound));
        saveAlertsToFile();
        logActivity("Price alert set for " + upper + " — Lower: $" + lowerBound + ", Upper: $" + upperBound);
        System.out.println("✅ Alert set for " + upper + " — Lower: $" + lowerBound + ", Upper: $" + upperBound);
    }

    /**
     * Iterate every configured alert, fetch the current price (uses cache),
     * and fire AlertManager for any stock whose price is out of bounds.
     *
     * @return the number of violations triggered
     */
    public int checkAlerts() {
        if (priceAlerts.isEmpty()) {
            System.out.println("No price alerts configured. Use option 4 to set one.");
            return 0;
        }
        System.out.println("Checking " + priceAlerts.size() + " alert(s)...");
        List<AlertManager.Event> violations = new ArrayList<>();

        for (PriceAlert alert : priceAlerts.values()) {
            try {
                StockData data = avClient.getStockData(alert.getSymbol());
                if (!data.isValid()) {
                    System.out.println("   ⚠️  " + alert.getSymbol() + ": no valid data, skipping");
                    continue;
                }
                double price = Double.parseDouble(data.getPrice());
                if (price < alert.getLowerBound()) {
                    violations.add(new AlertManager.Event(
                        alert.getSymbol(), price, alert.getLowerBound(), true));
                    logActivity("Alert triggered: " + alert.getSymbol()
                        + " $" + price + " < lower $" + alert.getLowerBound());
                } else if (price > alert.getUpperBound()) {
                    violations.add(new AlertManager.Event(
                        alert.getSymbol(), price, alert.getUpperBound(), false));
                    logActivity("Alert triggered: " + alert.getSymbol()
                        + " $" + price + " > upper $" + alert.getUpperBound());
                }
            } catch (NumberFormatException e) {
                System.out.println("   ⚠️  " + alert.getSymbol() + ": couldn't parse price");
            } catch (AlphaVantageClient.RateLimitException e) {
                System.out.println("   ⚠️  " + alert.getSymbol() + ": rate-limited, stopping check.");
                break;
            } catch (Exception e) {
                System.out.println("   ⚠️  " + alert.getSymbol() + ": " + e.getMessage());
            }
        }

        if (violations.isEmpty()) {
            System.out.println("✅ All " + priceAlerts.size() + " alert(s) within bounds.");
        } else {
            AlertManager.notify(violations);
        }
        return violations.size();
    }

    /** Remove an alert by symbol. Returns true if one existed. */
    public boolean removeAlert(String symbol) {
        String upper = symbol.toUpperCase().trim();
        if (priceAlerts.remove(upper) != null) {
            saveAlertsToFile();
            logActivity("Removed price alert for " + upper);
            return true;
        }
        return false;
    }

    private void loadAlertsFromFile() {
        File file = new File(ALERTS_FILE);
        if (!file.exists()) return;
        try (BufferedReader r = new BufferedReader(new FileReader(file))) {
            String line;
            int loaded = 0;
            while ((line = r.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] parts = line.split("\\|");
                if (parts.length != 3) continue;
                try {
                    String sym = parts[0].trim().toUpperCase();
                    double lo = Double.parseDouble(parts[1].trim());
                    double hi = Double.parseDouble(parts[2].trim());
                    if (!sym.isEmpty() && lo < hi) {
                        priceAlerts.put(sym, new PriceAlert(sym, lo, hi));
                        loaded++;
                    }
                } catch (NumberFormatException e) {
                    // malformed line, skip
                }
            }
            if (loaded > 0) {
                System.out.println("🔔 Loaded " + loaded + " price alert(s) from previous session.");
            }
        } catch (IOException e) {
            System.err.println("Failed to load alerts: " + e.getMessage());
        }
    }

    private void saveAlertsToFile() {
        try (BufferedWriter w = new BufferedWriter(new FileWriter(ALERTS_FILE))) {
            for (PriceAlert a : priceAlerts.values()) {
                w.write(a.getSymbol() + "|" + a.getLowerBound() + "|" + a.getUpperBound());
                w.newLine();
            }
        } catch (IOException e) {
            System.err.println("Failed to save alerts: " + e.getMessage());
        }
    }

    public Map<String, PriceAlert> getPriceAlerts() {
        return Collections.unmodifiableMap(priceAlerts);
    }

    private void logActivity(String activity) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(SESSION_LOG_FILE, true))) {
            writer.write("[" + LocalDateTime.now().format(formatter) + "] " + activity);
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Failed to log activity: " + e.getMessage());
        }
    }

    public void logValidationError(String symbol) {
        logActivity("Failed to add " + symbol + " — Invalid stock symbol");
    }

    public static class PriceAlert {
        private final String symbol;
        private final double lowerBound;
        private final double upperBound;

        public PriceAlert(String symbol, double lowerBound, double upperBound) {
            this.symbol = symbol;
            this.lowerBound = lowerBound;
            this.upperBound = upperBound;
        }

        public String getSymbol() { return symbol; }
        public double getLowerBound() { return lowerBound; }
        public double getUpperBound() { return upperBound; }
    }
}