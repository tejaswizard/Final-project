package Classes;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

/**
 * Talks to the Alpha Vantage GLOBAL_QUOTE endpoint with a daily cache in front
 * of it. Cached entries fetched today are returned without an API call, which
 * matters because the free tier is capped at ~25 calls/day.
 *
 * Invalid symbols are also cached so we don't burn calls re-checking junk input.
 */
public class AlphaVantageClient {

    // Tip: in production, load via System.getenv("ALPHA_VANTAGE_API_KEY").
    private static final String API_KEY = "4W8USZD7K6PXDT4T";
    private static final String BASE_URL = "https://www.alphavantage.co/query";

    private final HttpClient client = HttpClient.newHttpClient();
    private final StockCache cache;

    public AlphaVantageClient() {
        this.cache = new StockCache();
    }

    public AlphaVantageClient(StockCache cache) {
        this.cache = cache;
    }

    public StockCache getCache() {
        return cache;
    }

    /**
     * Returns stock data for the symbol. Uses today's cached entry if available,
     * otherwise hits the API and stores the result.
     *
     * @throws InvalidStockException if the symbol does not exist on the API
     * @throws RateLimitException if the API has rate-limited us
     * @throws Exception for network or HTTP errors
     */
    public StockData getStockData(String symbol) throws Exception {
        String upper = normalize(symbol);
        if (upper.isEmpty()) {
            throw new InvalidStockException("Empty stock symbol.");
        }

        StockData cached = cache.get(upper);
        if (cached != null && cached.isFresh()) {
            if (!cached.isValid()) {
                throw new InvalidStockException("'" + upper + "' is not a valid stock symbol (cached).");
            }
            return cached;
        }
        return fetchAndCache(upper);
    }

    /**
     * Forces a fresh API call, bypassing the cache. The result is written back
     * to the cache on success.
     */
    public StockData refreshStockData(String symbol) throws Exception {
        return fetchAndCache(normalize(symbol));
    }

    /**
     * Returns true if the symbol exists on the API. Uses the cache, so repeated
     * validations of the same symbol on the same day cost zero API calls.
     */
    public boolean validateStockSymbol(String symbol) {
        try {
            getStockData(symbol);
            return true;
        } catch (InvalidStockException e) {
            return false;
        } catch (Exception e) {
            // Network errors / rate limits etc. - don't claim it's invalid;
            // bubble up via false here but the caller should be aware.
            return false;
        }
    }

    /**
     * Like validateStockSymbol but distinguishes "definitely invalid" from
     * "couldn't check right now" (rate limit / network). Useful for UX so we
     * don't lie to the user.
     */
    public ValidationResult validateDetailed(String symbol) {
        try {
            getStockData(symbol);
            return ValidationResult.VALID;
        } catch (InvalidStockException e) {
            return ValidationResult.INVALID;
        } catch (RateLimitException e) {
            return ValidationResult.RATE_LIMITED;
        } catch (Exception e) {
            return ValidationResult.NETWORK_ERROR;
        }
    }

    public enum ValidationResult { VALID, INVALID, RATE_LIMITED, NETWORK_ERROR }

    private StockData fetchAndCache(String symbol) throws Exception {
        String json = fetchRawQuote(symbol);

        if (isRateLimited(json)) {
            // Don't poison the cache with an "invalid" marker — this isn't the symbol's fault.
            throw new RateLimitException(
                "Alpha Vantage rate limit reached. The free tier allows ~25 calls/day. " +
                "Try again tomorrow or use cached data.");
        }
        if (isInvalidStock(json)) {
            StockData invalid = StockData.invalid(symbol);
            cache.put(invalid);
            throw new InvalidStockException("'" + symbol + "' is not a valid stock symbol.");
        }

        StockData data = StockData.parse(json);
        if (!data.isValid()) {
            // Parsed but no price — treat as invalid.
            StockData invalid = StockData.invalid(symbol);
            cache.put(invalid);
            throw new InvalidStockException("'" + symbol + "' did not return a price (likely invalid).");
        }
        cache.put(data);
        return data;
    }

    /** Raw HTTP call. Kept package-private for testing. */
    String fetchRawQuote(String symbol) throws Exception {
        String url = BASE_URL
            + "?function=GLOBAL_QUOTE"
            + "&symbol=" + symbol
            + "&apikey=" + API_KEY;

        HttpRequest req = HttpRequest.newBuilder()
            .uri(URI.create(url))
            .GET()
            .build();

        HttpResponse<String> resp = client.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() != 200) {
            throw new RuntimeException("HTTP error: " + resp.statusCode());
        }
        return resp.body();
    }

    /**
     * True if Alpha Vantage explicitly indicates the symbol is invalid, or if the response is missing.
     */
    boolean isInvalidStock(String json) {
        if (json == null) return true;
        // Explicit error message from the API
        if (json.contains("\"Error Message\"")) return true;
        // Empty Global Quote object — symbol didn't match anything
        if (json.contains("\"Global Quote\": {}")
            || json.contains("\"Global Quote\":{}")) return true;
        // Has Global Quote but no price field — malformed/empty
        if (json.contains("\"Global Quote\"") && !json.contains("\"05. price\"")) return true;
        return false;
    }

    boolean isRateLimited(String json) {
        if (json == null) return false;
        boolean noPrice = !json.contains("\"05. price\"");
        // Alpha Vantage uses "Information" or "Note" when throttling.
        return noPrice && (json.contains("\"Information\"") || json.contains("\"Note\""));
    }

    private static String normalize(String symbol) {
        return symbol == null ? "" : symbol.toUpperCase().trim();
    }

    public static String getApiKey() {
        return API_KEY;
    }

    /** Thrown when the symbol doesn't exist on the API. */
    public static class InvalidStockException extends RuntimeException {
        private static final long serialVersionUID = 1L;
        public InvalidStockException(String msg) { super(msg); }
    }

    /** Thrown when the API has rate-limited us. */
    public static class RateLimitException extends RuntimeException {
        private static final long serialVersionUID = 1L;
        public RateLimitException(String msg) { super(msg); }
    }
}