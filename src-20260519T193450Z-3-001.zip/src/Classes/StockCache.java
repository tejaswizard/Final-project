package Classes;

import java.io.*;
import java.util.*;

/**
 * File-backed cache for stock data. Each line in the cache file represents one
 * stock symbol. The cache is loaded into memory on construction and re-persisted
 * after each save.
 *
 * The cache stores both VALID and INVALID symbols so we don't waste API calls
 * on symbols we've already learned are bad.
 */
public class StockCache {

    private static final String CACHE_FILE = "stock_cache.txt";

    private final Map<String, StockData> cache = new HashMap<>();
    private final File cacheFile;

    public StockCache() {
        this(CACHE_FILE);
    }

    /** Constructor that lets you point at a different file (useful for tests). */
    public StockCache(String path) {
        this.cacheFile = new File(path);
        load();
    }

    public StockData get(String symbol) {
        if (symbol == null) return null;
        return cache.get(symbol.toUpperCase().trim());
    }

    /** Returns true only if we have a same-day, VALID entry for this symbol. */
    public boolean hasFreshValid(String symbol) {
        StockData d = get(symbol);
        return d != null && d.isFresh() && d.isValid();
    }

    /** Returns true if we have any same-day entry (valid or invalid). */
    public boolean hasFreshAny(String symbol) {
        StockData d = get(symbol);
        return d != null && d.isFresh();
    }

    public void put(StockData data) {
        if (data == null || data.getSymbol() == null) return;
        cache.put(data.getSymbol().toUpperCase(), data);
        persist();
    }

    public int size() {
        return cache.size();
    }

    public Collection<StockData> all() {
        return Collections.unmodifiableCollection(cache.values());
    }

    public void clearStale() {
        cache.values().removeIf(d -> !d.isFresh());
        persist();
    }

    public void clearAll() {
        cache.clear();
        persist();
    }

    private void load() {
        if (!cacheFile.exists()) return;
        try (BufferedReader r = new BufferedReader(new FileReader(cacheFile))) {
            String line;
            int loaded = 0;
            while ((line = r.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                StockData d = StockData.fromCacheLine(line);
                if (d != null && d.getSymbol() != null && !d.getSymbol().isEmpty()) {
                    cache.put(d.getSymbol().toUpperCase(), d);
                    loaded++;
                }
            }
            if (loaded > 0) {
                System.out.println("📦 Loaded " + loaded + " stock(s) from local cache.");
            }
        } catch (IOException e) {
            System.err.println("Failed to load stock cache: " + e.getMessage());
        }
    }

    private void persist() {
        try (BufferedWriter w = new BufferedWriter(new FileWriter(cacheFile))) {
            for (StockData d : cache.values()) {
                w.write(d.toCacheLine());
                w.newLine();
            }
        } catch (IOException e) {
            System.err.println("Failed to write stock cache: " + e.getMessage());
        }
    }
}
