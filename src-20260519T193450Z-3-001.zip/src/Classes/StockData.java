package Classes;

import java.time.LocalDate;

/**
 * Holds parsed stock quote data. Can serialize itself to/from a single
 * pipe-delimited line for cache file storage.
 *
 * Format: SYMBOL|PRICE|CHANGE|CHANGE_PCT|HIGH|LOW|OPEN|VOLUME|FETCH_DATE|STATUS
 */
public class StockData {

    private String symbol = "N/A";
    private String price = "N/A";
    private String change = "N/A";
    private String changePercent = "N/A";
    private String high = "N/A";
    private String low = "N/A";
    private String open = "N/A";
    private String volume = "N/A";
    private LocalDate fetchDate = LocalDate.now();
    private boolean valid = true;

    public StockData() {}

    /** A "fresh" entry is one fetched today. Older entries should be re-fetched. */
    public boolean isFresh() {
        return fetchDate != null && fetchDate.equals(LocalDate.now());
    }

    /** Build an "invalid symbol" marker so we can remember bad symbols and not re-query them. */
    public static StockData invalid(String symbol) {
        StockData s = new StockData();
        s.symbol = symbol == null ? "N/A" : symbol.toUpperCase();
        s.valid = false;
        s.fetchDate = LocalDate.now();
        return s;
    }

    /** Parse an Alpha Vantage GLOBAL_QUOTE JSON response. */
    public static StockData parse(String jsonResponse) {
        StockData d = new StockData();
        try {
            d.symbol = extractJsonValue(jsonResponse, "01. symbol");
            d.open = extractJsonValue(jsonResponse, "02. open");
            d.high = extractJsonValue(jsonResponse, "03. high");
            d.low = extractJsonValue(jsonResponse, "04. low");
            d.price = extractJsonValue(jsonResponse, "05. price");
            d.volume = extractJsonValue(jsonResponse, "06. volume");
            d.change = extractJsonValue(jsonResponse, "09. change");
            d.changePercent = extractJsonValue(jsonResponse, "10. change percent");
            d.fetchDate = LocalDate.now();
            // It's only really valid if we actually found a price
            d.valid = !"N/A".equals(d.price) && !d.price.isEmpty();
        } catch (Exception e) {
            d.valid = false;
        }
        return d;
    }

    /** Serialize for a single cache line. */
    public String toCacheLine() {
        return String.join("|",
            safe(symbol), safe(price), safe(change), safe(changePercent),
            safe(high), safe(low), safe(open), safe(volume),
            fetchDate == null ? LocalDate.now().toString() : fetchDate.toString(),
            valid ? "VALID" : "INVALID");
    }

    /** Deserialize a cache line back into a StockData. Returns null if malformed. */
    public static StockData fromCacheLine(String line) {
        if (line == null) return null;
        String[] parts = line.split("\\|", -1);
        if (parts.length < 10) return null;
        StockData d = new StockData();
        d.symbol = parts[0];
        d.price = parts[1];
        d.change = parts[2];
        d.changePercent = parts[3];
        d.high = parts[4];
        d.low = parts[5];
        d.open = parts[6];
        d.volume = parts[7];
        try {
            d.fetchDate = LocalDate.parse(parts[8]);
        } catch (Exception e) {
            d.fetchDate = LocalDate.now().minusDays(1); // treat as stale
        }
        d.valid = "VALID".equalsIgnoreCase(parts[9]);
        return d;
    }

    private static String safe(String s) {
        if (s == null || s.isEmpty()) return "N/A";
        // protect the pipe separator
        return s.replace("|", "/");
    }

    /**
     * Small JSON value extractor. Works fine for Alpha Vantage's GLOBAL_QUOTE
     * shape; not a general-purpose parser.
     */
    private static String extractJsonValue(String json, String key) {
        if (json == null) return "N/A";
        String searchKey = "\"" + key + "\"";
        int idx = json.indexOf(searchKey);
        if (idx == -1) return "N/A";
        idx = json.indexOf(":", idx);
        if (idx == -1) return "N/A";
        idx++;
        while (idx < json.length() && Character.isWhitespace(json.charAt(idx))) idx++;
        if (idx >= json.length()) return "N/A";

        if (json.charAt(idx) == '"') {
            int end = json.indexOf("\"", idx + 1);
            if (end == -1) return "N/A";
            return json.substring(idx + 1, end);
        }
        int end = idx;
        while (end < json.length() && json.charAt(end) != ',' && json.charAt(end) != '}') end++;
        return json.substring(idx, end).trim();
    }

    // --- getters/setters ---
    public String getSymbol() { return symbol; }
    public String getPrice() { return price; }
    public String getChange() { return change; }
    public String getChangePercent() { return changePercent; }
    public String getHigh() { return high; }
    public String getLow() { return low; }
    public String getOpen() { return open; }
    public String getVolume() { return volume; }
    public LocalDate getFetchDate() { return fetchDate; }
    public boolean isValid() { return valid; }

    public void setSymbol(String s) { this.symbol = s; }
    public void setPrice(String s) { this.price = s; }
    public void setChange(String s) { this.change = s; }
    public void setChangePercent(String s) { this.changePercent = s; }
    public void setHigh(String s) { this.high = s; }
    public void setLow(String s) { this.low = s; }
    public void setOpen(String s) { this.open = s; }
    public void setVolume(String s) { this.volume = s; }
    public void setFetchDate(LocalDate d) { this.fetchDate = d; }
    public void setValid(boolean v) { this.valid = v; }
}
