package Classes;

import java.awt.Toolkit;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Handles price-alert notifications. Always plays an audible beep and prints
 * to the terminal; additionally shows a JavaFX dialog if JavaFX is available
 * on the runtime module/class path.
**/
public class AlertManager {

    private static final AtomicBoolean initialized = new AtomicBoolean(false);
    private static volatile boolean fxAvailable = false;

    // Cached reflected handles (populated by initialize())
    private static Class<?> platformClass;
    private static Class<?> alertClass;
    private static Class<?> alertTypeClass;
    private static Object warningType;
    private static Method runLaterMethod;

    private AlertManager() {}

    /** Idempotent. Safe to call multiple times. */
    public static synchronized void initialize() {
        if (!initialized.compareAndSet(false, true)) return;
        try {
            platformClass   = Class.forName("javafx.application.Platform");
            alertClass      = Class.forName("javafx.scene.control.Alert");
            alertTypeClass  = Class.forName("javafx.scene.control.Alert$AlertType");
            warningType     = alertTypeClass.getField("WARNING").get(null);
            runLaterMethod  = platformClass.getMethod("runLater", Runnable.class);

            // Boot the JavaFX toolkit. Swallow "already started" if it happens.
            Method startup = platformClass.getMethod("startup", Runnable.class);
            try {
                startup.invoke(null, (Runnable) () -> {});
            } catch (Exception alreadyStarted) {
                // not a problem
            }

            // Don't auto-exit the FX runtime when the last window closes
            Method setImplicitExit = platformClass.getMethod("setImplicitExit", boolean.class);
            setImplicitExit.invoke(null, false);

            fxAvailable = true;
            System.out.println("🎨 JavaFX alerts enabled.");
        } catch (Throwable t) {
            fxAvailable = false;
            System.out.println("ℹ️  JavaFX not detected — alerts will use terminal + system beep only.");
            System.out.println("   (To enable popup dialogs, see the README for JavaFX setup.)");
        }
    }

    public static boolean isFxAvailable() {
        return fxAvailable;
    }

    /**
     * Trigger an alert covering one or more violations. Always beeps + prints;
     * shows a single JavaFX summary dialog if FX is available.
     */
    public static void notify(List<Event> events) {
        if (events == null || events.isEmpty()) return;

        // 1) Audible beep — works on most desktops even without JavaFX
        try {
            Toolkit.getDefaultToolkit().beep();
        } catch (Throwable ignored) {
            // headless / no audio device — that's fine
        }

        // 2) Always print to terminal so the user sees SOMETHING even without FX
        System.out.println();
        System.out.println("🔔 PRICE ALERT — " + events.size() + " stock(s) out of bounds:");
        for (Event e : events) {
            System.out.println("   • " + e.describe());
        }
        System.out.println();

        // 3) Best-effort JavaFX popup
        if (fxAvailable) showFxDialog(events);
    }

    private static void showFxDialog(List<Event> events) {
        Runnable showAction = () -> {
            try {
                Object alert = alertClass.getConstructor(alertTypeClass).newInstance(warningType);
                alertClass.getMethod("setTitle", String.class)
                          .invoke(alert, "Stock Price Alerts");
                alertClass.getMethod("setHeaderText", String.class)
                          .invoke(alert, events.size() + " stock(s) outside your alert bounds");

                StringBuilder body = new StringBuilder();
                for (Event e : events) {
                    body.append("• ").append(e.describe()).append("\n");
                }
                alertClass.getMethod("setContentText", String.class)
                          .invoke(alert, body.toString());
                alertClass.getMethod("show").invoke(alert);
            } catch (Throwable t) {
                System.err.println("Failed to render JavaFX alert: " + t.getMessage());
            }
        };
        try {
            runLaterMethod.invoke(null, showAction);
        } catch (Throwable t) {
            System.err.println("JavaFX Platform.runLater failed: " + t.getMessage());
            fxAvailable = false;
        }
    }

    /** Shut down the JavaFX toolkit cleanly on program exit. */
    public static void shutdown() {
        if (!fxAvailable) return;
        try {
            platformClass.getMethod("exit").invoke(null);
        } catch (Throwable ignored) {
            // we're exiting anyway
        }
    }

    /** One out-of-bounds occurrence for a single stock. */
    public static class Event {
        public final String symbol;
        public final double price;
        public final double bound;
        public final boolean wentBelow;

        public Event(String symbol, double price, double bound, boolean wentBelow) {
            this.symbol = symbol;
            this.price = price;
            this.bound = bound;
            this.wentBelow = wentBelow;
        }

        public String describe() {
            return String.format("%s at $%.2f is %s your %s bound of $%.2f",
                symbol, price,
                wentBelow ? "BELOW" : "ABOVE",
                wentBelow ? "lower" : "upper",
                bound);
        }
    }
}
