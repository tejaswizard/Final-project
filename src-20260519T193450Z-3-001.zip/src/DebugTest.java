public class DebugTest {
    public static void main(String[] args) {
        // Simulate what extractJsonValue does
        String json = "{\"Global Quote\":{\"01. symbol\":\"AAPL\",\"05. price\":\"150.95\"}}";
        String key = "05. price";
        
        String searchKey = "\"" + key + "\"";
        int startIndex = json.indexOf(searchKey);
        System.out.println("searchKey: " + searchKey);
        System.out.println("startIndex of key: " + startIndex);
        
        if (startIndex == -1) {
            System.out.println("Key not found!");
            return;
        }
        
        startIndex = json.indexOf(":", startIndex) + 1;
        System.out.println("startIndex after ':': " + startIndex);
        System.out.println("char at startIndex: '" + json.charAt(startIndex) + "'");
        
        // Skip whitespace
        while (startIndex < json.length() && Character.isWhitespace(json.charAt(startIndex))) {
            startIndex++;
        }
        System.out.println("startIndex after whitespace: " + startIndex);
        System.out.println("char at startIndex: '" + json.charAt(startIndex) + "'");
        
        boolean inQuotes = json.charAt(startIndex) == '"';
        System.out.println("inQuotes: " + inQuotes);
        
        if (inQuotes) {
            int endIndex = json.indexOf("\"", startIndex + 1);
            System.out.println("endIndex: " + endIndex);
            String result = json.substring(startIndex + 1, endIndex);
            System.out.println("Result: " + result);
        }
    }
}
