import Classes.AlertManager;
import Classes.AlphaVantageClient;
import Classes.Portfolio;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        AlertManager.initialize();             // boots JavaFX if available
        Portfolio portfolio = new Portfolio(); // loads saved data automatically
        Scanner sc = new Scanner(System.in);
        boolean running = true;

        System.out.println("\n=== Welcome to Stock Tracker ===");
        System.out.println("Stock data is cached daily to preserve API quota (free tier: ~25 calls/day).");

        while (running) {
            printMenu();
            int choice = readInt(sc);

            switch (choice) {
                case 1  -> System.out.println(portfolio.getPortfolioSummary());
                case 2  -> addStocksFlow(sc, portfolio);
                case 3  -> removeStockFlow(sc, portfolio);
                case 4  -> setAlertFlow(sc, portfolio);
                case 5  -> portfolio.checkAlerts();
                case 6  -> portfolio.saveToFile();
                case 7  -> portfolio.viewSessionHistory();
                case 8  -> portfolio.refreshAllStocks();
                case 9  -> portfolio.showCacheStatus();
                case 10 -> {
                    portfolio.saveToFile();
                    AlertManager.shutdown();
                    System.out.println("Exiting...");
                    running = false;
                }
                case -1 -> { /* bad input, already complained */ }
                default -> System.out.println("Invalid choice. Please try again.");
            }
        }
        sc.close();
    }

    private static void printMenu() {
        System.out.println("\n=== Stock Tracker ===");
        System.out.println(" 1. View Your Portfolio");
        System.out.println(" 2. Add a stock to track");
        System.out.println(" 3. Remove a stock");
        System.out.println(" 4. Set price alerts for a stock");
        System.out.println(" 5. Check price alerts now");
        System.out.println(" 6. Save Portfolio");
        System.out.println(" 7. View Session History");
        System.out.println(" 8. Refresh all stocks from API (uses quota)");
        System.out.println(" 9. View cache status");
        System.out.println("10. Exit");
        System.out.print("Choice: ");
    }

    private static int readInt(Scanner sc) {
        try {
            int n = sc.nextInt();
            sc.nextLine();
            return n;
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a number.");
            sc.nextLine();
            return -1;
        }
    }

    private static void addStocksFlow(Scanner sc, Portfolio portfolio) {
        System.out.print("Enter stock symbol(s) separated by commas (e.g., AAPL,GOOGL,MSFT): ");
        String input = sc.nextLine();
        if (input == null || input.isBlank()) {
            System.out.println("No input provided.");
            return;
        }

        for (String raw : input.split(",")) {
            String sym = raw.trim();
            if (sym.isEmpty()) continue;

            AlphaVantageClient.ValidationResult result = portfolio.validateStockDetailed(sym);
            switch (result) {
                case VALID -> portfolio.addStock(sym);
                case INVALID -> {
                    portfolio.logValidationError(sym);
                    System.out.println("❌ " + sym.toUpperCase() + ": invalid stock symbol. Try again with a real ticker.");
                }
                case RATE_LIMITED -> System.out.println("⚠️  " + sym.toUpperCase()
                    + ": API rate limit reached — can't verify right now. Skipping.");
            }
        }
    }

    private static void removeStockFlow(Scanner sc, Portfolio portfolio) {
        System.out.print("Enter stock symbol to remove: ");
        String input = sc.nextLine();
        if (input == null || input.isBlank()) {
            System.out.println("No input provided.");
            return;
        }
        portfolio.removeStock(input);
    }

    private static void setAlertFlow(Scanner sc, Portfolio portfolio) {
        System.out.print("Enter stock symbol for alert: ");
        String symbol = sc.nextLine();
        if (symbol == null || symbol.isBlank()) {
            System.out.println("No input provided.");
            return;
        }
        try {
            System.out.print("Enter lower price limit: ");
            double lower = Double.parseDouble(sc.nextLine().trim());
            System.out.print("Enter upper price limit: ");
            double upper = Double.parseDouble(sc.nextLine().trim());
            portfolio.setPriceAlert(symbol, lower, upper);
        } catch (NumberFormatException e) {
            System.out.println("❌ Invalid price input. Please enter valid numbers.");
        }
    }
}